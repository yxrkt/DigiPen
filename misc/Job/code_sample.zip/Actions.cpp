#include "MainPCH.h"
#include "StageManager.h"
#include "LevelEditorManager.h"
#include "Actions.h"
#include "PointLite.h"

#include "LeakCheck.h"
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;


#pragma region Misc

void Action::StoreAsBlockPars( std::vector< ModBlockPars > &pars, const BlockPtrSet &blocks )
{
  for ( BlockPtrSet::const_iterator i = blocks.begin(); i != blocks.end(); ++i )
  {
    ModBlockPars blockInfo;

    Block *pBlock   = *i;
    D3DXVECTOR3 pos = pBlock->GetEntity()->GetPosition();
    blockInfo.pos   = StageMgr->GetBlockRowCol( pos.x, pos.y );
    blockInfo.type  = LevelEditMgr->blockTypeMap[pBlock->Name + "Block"];
    blockInfo.pit   = pBlock->Pit;

    pars.push_back( blockInfo );
  }
}

#pragma endregion

ActionResizeDimensions::ActionResizeDimensions( const ResizeDimsParsIn &next, 
                                                const ResizeDimsParsIn &prev )
{
  m_next.width  = next.width;
  m_next.height = next.height;
  m_prev.width  = prev.width;
  m_prev.height = prev.height;

  StoreDeletedBlockTypes();
}

void ActionResizeDimensions::Execute( bool forward )
{
  ResizeDimsPars &pars = forward ? m_next : m_prev;

  int prevWidth     = StageMgr->GridWidth;
  int prevHeight    = StageMgr->GridHeight;
  int newWidth      = pars.width;
  int newHeight     = pars.height;

  SetCurrentDirectoryA( LevelEditMgr->STARTUP_DIRECTORY.c_str() );

  LevelEditMgr->selectedBlocks.clear();

  // watch for bad index
  LevelEditMgr->blockTypeIndex = min( LevelEditMgr->blockTypeIndex, LevelEditMgr->blockTypes.size() - 1 );

  for ( int i = StageMgr->GridHeight; i < newHeight; ++i )
    StageMgr->AddRow( LevelEditMgr->blockTypes[LevelEditMgr->blockTypeIndex], LevelEditMgr->createPit );

  for ( int i = StageMgr->GridHeight; i > newHeight; --i )
    StageMgr->DelRow();

  for ( int i = StageMgr->GridWidth; i < newWidth; ++i )
    StageMgr->AddCol( LevelEditMgr->blockTypes[LevelEditMgr->blockTypeIndex], LevelEditMgr->createPit );

  for ( int i = StageMgr->GridWidth; i > newWidth; --i )
    StageMgr->DelCol();

  if ( !pars.blockStates.empty() )
  {
    int rBegin = prevHeight == newHeight ? 0 : prevHeight;
    int cBegin = prevWidth  == newWidth  ? 0 : prevWidth;

    for ( int r = rBegin, i = 0; r < newHeight; ++r )
    {
      for ( int c = cBegin; c < newWidth; ++c, ++i )
      {
        StageMgr->ReplaceBlock( r, c, LevelEditMgr->blockTypes[pars.blockStates[i].type] );
        StageMgr->GetBlock( r, c )->SetAsPit( pars.blockStates[i].pit );
      }
    }
    StageMgr->UpdateBlockTypeList();
  }

  StageMgr->RepositionDoodads();

  // update dimensions in level editor app
  LevelEditMgr->SendToEditor( BBM_DIMENSIONS, 0, MAKELONG( newWidth, newHeight ) );
}

void ActionResizeDimensions::StoreDeletedBlockTypes( void )
{
  if ( m_next.width < m_prev.width || m_next.height < m_prev.height )
  {
    int rBegin = m_next.height == m_prev.height ? 0 : m_next.height;
    int cBegin = m_next.width  == m_prev.width  ? 0 : m_next.width;

    for ( int r = rBegin, i = 0; r < m_prev.height; ++r )
    {
      for ( int c = cBegin; c < m_prev.width; ++c, ++i )
      {
        BlockStatePars statePars;
        Block *pBlock  = StageMgr->GetBlock( r, c );
        statePars.type = LevelEditMgr->blockTypeMap[pBlock->Name + "Block"];
        statePars.pit  = pBlock->Pit;
        m_prev.blockStates.push_back( statePars );
      }
    }
  }
}

ActionResizeBlocks::ActionResizeBlocks( int next, int prev )
: m_next( next )
, m_prev( prev )
{
}

void ActionResizeBlocks::Execute( bool forward )
{
  int newBlockSize = forward ? m_next : m_prev;

  StageMgr->SetBlockSize( newBlockSize );
  LevelEditMgr->gridZPos = LevelEditMgr->gridHeight * (float)newBlockSize;

  StageMgr->RepositionDoodads();

  // update block size in editor app
  LevelEditMgr->SendToEditor( BBM_BLOCKSIZE, 0, newBlockSize );
}

ActionDeleteBlocks::ActionDeleteBlocks( const BlockPtrSet &blocks )
{
  StoreAsBlockPars( m_deletedBlocks, blocks );
}

void ActionDeleteBlocks::Execute( bool forward )
{
  if ( !forward && LevelEditMgr->editMode == EM_SELECT_BLOCKS )
    LevelEditMgr->selectedBlocks.clear();

  size_t nBlocks = m_deletedBlocks.size();
  for ( size_t i = 0; i < nBlocks; ++i )
  {
    ModBlockPars &blockInfo = m_deletedBlocks[i];
    bool pit = forward ? true : blockInfo.pit;
    Block *pBlock = StageMgr->GetBlock( blockInfo.pos.row, blockInfo.pos.col );
    pBlock->SetAsPit( pit );
    if ( forward && LevelEditMgr->editMode == EM_SELECT_BLOCKS )
      LevelEditMgr->selectedBlocks.insert( pBlock );
  }
}

ActionCreateBlocks::ActionCreateBlocks( const BlockPtrSet &blocks )
{
  StoreAsBlockPars( m_changedBlocks, blocks );
}

void ActionCreateBlocks::Execute( bool forward )
{
  if ( LevelEditMgr->editMode == EM_SELECT_BLOCKS )
    LevelEditMgr->selectedBlocks.clear();

  size_t nBlocks = m_changedBlocks.size();
  for ( size_t i = 0; i < nBlocks; ++i )
  {
    ModBlockPars &blockInfo = m_changedBlocks[i];
    Block **ppBlock = StageMgr->GetBlockPtr( blockInfo.pos.row, blockInfo.pos.col );

    int type = forward ? (int)LevelEditMgr->blockTypeIndex : blockInfo.type;
    StageMgr->ReplaceBlock( ppBlock, LevelEditMgr->blockTypes[type] );
    StageMgr->RespawnAllBlocks();

    StageMgr->UpdateBlockTypeList();

    (*ppBlock)->SetAsPit( forward ? LevelEditMgr->createPit : blockInfo.pit );

    if ( LevelEditMgr->editMode == EM_SELECT_BLOCKS )
      LevelEditMgr->selectedBlocks.insert( *ppBlock );
  }
}

ActionMoveBlocks::ActionMoveBlocks( const BlockPtrSet &blocks, const RowColPair &dir )
: m_dir ( dir )
{
  StoreAsBlockPars( m_movedBlocks, blocks );
}

void ActionMoveBlocks::Execute( bool forward )
{
  int transX = forward ? m_dir.col : -m_dir.col;
  int transY = forward ? m_dir.row : -m_dir.row;

  int c = ( transX < 0 ? 0 : 1 );
  int r = ( transY < 0 ? 0 : 1 );

  // this will prevent unpredictable behavior when moving multiple blocks
  std::sort( m_movedBlocks.begin(), m_movedBlocks.end(), std::ptr_fun( g_blockXYSorters[r][c] ) );

  size_t nBlocks = m_movedBlocks.size();
  for ( size_t i = 0; i < nBlocks; ++i )
  {
    ModBlockPars &blockInfo = m_movedBlocks[i];
    int blockX = blockInfo.pos.col;
    int blockY = blockInfo.pos.row;
    if ( !forward )
    {
      blockX -= transX;
      blockY -= transY;
    }
    StageMgr->SwapBlocks( StageMgr->GetBlockPtr( blockY, blockX ), 
                          StageMgr->GetBlockPtr( blockY + transY, blockX + transX ) );
  }
  StageMgr->RepositionBlocks();
}

ActionSetBlockCreateParams::ActionSetBlockCreateParams( int type, bool pit )
: m_typeNext( type )
, m_typePrev( (int)LevelEditMgr->blockTypeIndex )
, m_pitNext( pit )
, m_pitPrev( LevelEditMgr->createPit )
{
}

void ActionSetBlockCreateParams::Execute( bool forward )
{
  LevelEditMgr->blockTypeIndex = forward ? m_typeNext : m_typePrev;
  LevelEditMgr->createPit      = forward ? m_pitNext  : m_pitPrev;

  // update editor app
  LevelEditMgr->SendToEditor( BBM_CREATION_TYPE, LevelEditMgr->blockTypeIndex, 
                                                 LevelEditMgr->createPit );
}

ActionCreateDoodad::ActionCreateDoodad( int type, const RowColPair &pos )
: m_type( type )
, m_pos( pos )
{
}

void ActionCreateDoodad::Execute( bool forward )
{
  // create entity in middle of square in grid
  D3DXVECTOR3 pos = StageMgr->GetBlock( m_pos.row, m_pos.col )->GetEntity()->GetPosition();
  pos.z = LevelEditMgr->gridZPos;

  if ( forward )
    StageMgr->AddDoodad( LevelEditMgr->doodadTypes[m_type], pos );

  else
    StageMgr->DelDoodad( m_pos );
}

ActionSetDoodadCreateParams::ActionSetDoodadCreateParams( int type )
: m_typeNext( type )
, m_typePrev( (int)LevelEditMgr->doodadTypeIndex )
{
}

void ActionSetDoodadCreateParams::Execute( bool forward )
{
  LevelEditMgr->doodadTypeIndex = forward ? m_typeNext : m_typePrev;
  // TODO: Add update message for editor app
}

ActionDeleteDoodads::ActionDeleteDoodads( const RCEntityMap &doodads )
{
  for ( RCEntityMap::const_iterator i = doodads.begin(); i != doodads.end(); ++i )
  {
    ModDoodadPars doodadInfo;

    Entity *pDoodad = i->second;
    D3DXVECTOR3 pos = pDoodad->GetPosition();
    doodadInfo.pos  = StageMgr->GetBlockRowCol( pos.x, pos.y );
    doodadInfo.type = LevelEditMgr->doodadTypeMap[pDoodad->GetName()];

    m_deletedDoodads.push_back( doodadInfo );
  }
}

void ActionDeleteDoodads::Execute( bool forward )
{
  size_t nDoodads = m_deletedDoodads.size();

  if ( forward )
  {
    for ( size_t i = 0; i < nDoodads; ++i )
    {
      ModDoodadPars &doodadInfo = m_deletedDoodads[i];
      StageMgr->DelDoodad( doodadInfo.pos.row, doodadInfo.pos.col );
    }

    LevelEditMgr->selectedDoodads.clear();
  }
  else
  {
    for ( size_t i = 0; i < nDoodads; ++i )
    {
      ModDoodadPars &doodadInfo = m_deletedDoodads[i];
      Block         *pBlock     = StageMgr->GetBlock( doodadInfo.pos.row, doodadInfo.pos.col );
      D3DXVECTOR3    pos        = pBlock->GetEntity()->GetPosition();

      pos.z                     = LevelEditMgr->gridZPos;
      StageMgr->AddDoodad( LevelEditMgr->doodadTypes[doodadInfo.type], pos );
    }
  }
}

ActionMoveDoodads::ActionMoveDoodads( const RCEntityMap &doodads, const RowColPair &dir )
: m_dir( dir )
{
  for ( RCEntityMap::const_iterator i = doodads.begin(); i != doodads.end(); ++i )
  {
    Entity       *pEntity = i->second;
    D3DXVECTOR3  &pos     = pEntity->GetPosition();

    m_doodadPosVec.push_back( StageMgr->GetBlockRowCol( pos.x, pos.y ) );
  }
}

void ActionMoveDoodads::Execute( bool forward )
{
  int dirX = forward ? m_dir.col : -m_dir.col;
  int dirY = forward ? m_dir.row : -m_dir.row;

  size_t nDoodads = m_doodadPosVec.size();

  for ( size_t i = 0; i < nDoodads; ++i )
  {
    RowColPair &doodadPos = m_doodadPosVec[i];
    if ( !forward )
    {
      doodadPos.row -= dirY;
      doodadPos.col -= dirX;
    }

    RowColPair beforePos = doodadPos;
    RowColPair nextPos   = { beforePos.row + dirY, beforePos.col + dirX };

    StageMgr->doodads_[nextPos] = StageMgr->doodads_[beforePos];

    Entity *pNextBlock = StageMgr->GetBlock( nextPos.row, nextPos.col )->GetEntity();

    D3DXVECTOR3 pos = pNextBlock->GetPosition();
    pos.z = StageMgr->doodads_[nextPos]->GetPosition().z;

    StageMgr->doodads_[nextPos]->GetPosition() = pos;
    LevelEditMgr->selectedDoodads[nextPos]     = pNextBlock;

    StageMgr->doodads_.erase( beforePos );
    LevelEditMgr->selectedDoodads.erase( beforePos );
  }
}

ActionCreatePointLight::ActionCreatePointLight( const D3DXVECTOR3 &pos, D3DCOLOR color, 
                                                float atten, float radius )
{
  m_light.pos    = pos;
  m_light.color  = color;
  m_light.atten  = atten;
  m_light.radius = radius;
}

void ActionCreatePointLight::Execute( bool forward )
{
  if ( forward )
  {
    StageMgr->AddLight( m_light.pos, m_light.radius, m_light.color, m_light.atten );
  }
  else
  {
    StageMgr->DelLight( m_light.pos );
    LevelEditMgr->selectedLights.clear();
  }
}

ActionDeletePointLights::ActionDeletePointLights( const EntityPtrList &lights )
{
  for ( EntityPtrList::const_iterator i = lights.begin(); i != lights.end(); ++i )
  {
    Entity    *pEntity = *i;
    PointLite *pLight  = pEntity->GetComponent<PointLite>();

    PointLightPars pars;
    pars.pos    = *pLight->pPos;
    pars.color  = pLight->GetD3DCOLOR();
    pars.atten  = pLight->GetIntensity();
    pars.radius = pLight->GetRadius();
    
    m_lights.push_back( pars );
  }
}

void ActionDeletePointLights::Execute( bool forward )
{
  size_t nLights = m_lights.size();

  if ( forward )
  {
    for ( size_t i = 0; i < nLights; ++i )
      StageMgr->DelLight( m_lights[i].pos );
  }
  else
  {
    for ( size_t i = 0; i < nLights; ++i )
    {
      StageMgr->AddLight( m_lights[i].pos, m_lights[i].radius, 
                          m_lights[i].color, m_lights[i].atten );
    }
  }
}

ActionMovePointLights::ActionMovePointLights( const std::vector< D3DXVECTOR3 > &prev, 
                                              const std::vector< D3DXVECTOR3 > &next )
: m_prev( prev )
, m_next( next )
{
}

void ActionMovePointLights::Execute( bool forward )
{
  size_t            nLights = m_prev.size();
  PointLitePtrList &lights  = StageMgr->lightList_;

  std::vector< D3DXVECTOR3 > &prev = forward ? m_prev : m_next;
  std::vector< D3DXVECTOR3 > &next = forward ? m_next : m_prev;

  for ( size_t i = 0; i < nLights; ++i )
  {
    FindPointLiteFunctor pred( prev[i] );
    PointLitePtrList::iterator found = std::find_if( lights.begin(), lights.end(), pred );
    *(*found)->pPos = next[i];
  }
}
