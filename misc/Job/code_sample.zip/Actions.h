#pragma once

#include "MainPCH.h"
#include "Manager.h"
#include "BlockStuff.h"
#include "StageManager.h"


#pragma region ParamStructs

struct ModBlockPars
{
  RowColPair pos;
  int        type;
  bool       pit;
};

struct ModDoodadPars
{
  RowColPair pos;
  int        type;
};

struct ResizeDimsParsIn
{
  int width, height;
};

struct BlockStatePars
{
  int  type;
  bool pit;
};

struct ResizeDimsPars
{
  int width, height;
  std::vector< BlockStatePars > blockStates;
};

struct PointLightPars
{
  D3DXVECTOR3 pos;
  D3DCOLOR    color;
  float       atten;
  float       radius;
};

#pragma endregion

#pragma region ModBlockParsSort

static bool BlockXYLessTopLeft( const ModBlockPars &lhs, const ModBlockPars &rhs )
{
  int xLhs = lhs.pos.col, yLhs = lhs.pos.row, xRhs = rhs.pos.col, yRhs = rhs.pos.row;
  if ( yLhs < yRhs ) return true;
  else if ( ( yLhs == yRhs ) && ( xLhs < xRhs ) ) return true;
  return false;
}

static bool BlockXYLessBottomLeft( const ModBlockPars &lhs, const ModBlockPars &rhs )
{
  int xLhs = lhs.pos.col, yLhs = lhs.pos.row, xRhs = rhs.pos.col, yRhs = rhs.pos.row;
  if ( yLhs > yRhs ) return true;
  else if ( ( yLhs == yRhs ) && ( xLhs < xRhs ) ) return true;
  return false;
}

static bool BlockXYLessBottomRight( const ModBlockPars &lhs, const ModBlockPars &rhs )
{
  int xLhs = lhs.pos.col, yLhs = lhs.pos.row, xRhs = rhs.pos.col, yRhs = rhs.pos.row;
  if ( yLhs > yRhs ) return true;
  else if ( ( yLhs == yRhs ) && ( xLhs > xRhs ) ) return true;
  return false;
}

static bool BlockXYLessTopRight( const ModBlockPars &lhs, const ModBlockPars &rhs )
{
  int xLhs = lhs.pos.col, yLhs = lhs.pos.row, xRhs = rhs.pos.col, yRhs = rhs.pos.row;
  if ( yLhs < yRhs ) return true;
  else if ( ( yLhs == yRhs ) && ( xLhs > xRhs ) ) return true;
  return false;
}

typedef bool ( *BLOCK_XY_SORTFN )( const ModBlockPars &, const ModBlockPars & );

static BLOCK_XY_SORTFN g_blockXYSorters[2][2] = 
{
  { &BlockXYLessTopLeft, &BlockXYLessTopRight },
  { &BlockXYLessBottomLeft, &BlockXYLessBottomRight }
};

#pragma endregion

// -----------------------------------------------------------------------------
// ! Base Action class
// -----------------------------------------------------------------------------
class Action
{
  public:
    Action( void )  {}
    virtual ~Action( void ) {}

    void Do( void )   { Execute( true ); }
    void Undo( void ) { Execute( false ); }

  protected:
    virtual void Execute( bool ) {};

    static void StoreAsBlockPars( std::vector< ModBlockPars > &pars, const BlockPtrSet &blocks );
};

// -----------------------------------------------------------------------------
// ! Resize Dimensions
// -----------------------------------------------------------------------------
class ActionResizeDimensions : public Action
{
  public:
    ActionResizeDimensions( const ResizeDimsParsIn &next, const ResizeDimsParsIn &prev );

  private:
    void Execute( bool forward );
    void StoreDeletedBlockTypes( void );

    ResizeDimsPars m_next;
    ResizeDimsPars m_prev;
};


// -----------------------------------------------------------------------------
// ! Resize Blocks
// -----------------------------------------------------------------------------
class ActionResizeBlocks : public Action
{
  public:
    ActionResizeBlocks( int next, int prev );

  private:
    void Execute( bool forward );

    int m_next;
    int m_prev;
};

// -----------------------------------------------------------------------------
// ! Delete Blocks
// -----------------------------------------------------------------------------
class ActionDeleteBlocks : public Action
{
  public:
    ActionDeleteBlocks( const BlockPtrSet &blocks );

  private:
    void Execute( bool forward );

    std::vector< ModBlockPars > m_deletedBlocks;
};

// -----------------------------------------------------------------------------
// ! Create Blocks
// -----------------------------------------------------------------------------
class ActionCreateBlocks : public Action
{
  public:
    ActionCreateBlocks( const BlockPtrSet &blocks );

  private:
    void Execute( bool forward );

    std::vector< ModBlockPars > m_changedBlocks;
};

// -----------------------------------------------------------------------------
// ! Move Blocks
// -----------------------------------------------------------------------------
class ActionMoveBlocks : public Action
{
  public:
    ActionMoveBlocks( const BlockPtrSet &blocks, const RowColPair &dir );

  private:
    void Execute( bool forward );

    std::vector< ModBlockPars > m_movedBlocks;
    RowColPair                  m_dir;
};

// -----------------------------------------------------------------------------
// ! Set Block Creation Parameters
// -----------------------------------------------------------------------------
class ActionSetBlockCreateParams : public Action
{
  public:
    ActionSetBlockCreateParams( int type, bool pit );

  private:
    void Execute( bool forward );

    int   m_typeNext, m_typePrev;
    bool  m_pitNext,  m_pitPrev;
};

// -----------------------------------------------------------------------------
// ! Create Doodad
// -----------------------------------------------------------------------------
class ActionCreateDoodad : public Action
{
  public:
    ActionCreateDoodad( int type, const RowColPair &pos );

  private:
    void Execute( bool forward );

    int         m_type;
    RowColPair  m_pos;
};

// -----------------------------------------------------------------------------
// ! Set Doodad Creation Parameters
// -----------------------------------------------------------------------------
class ActionSetDoodadCreateParams : public Action
{
  public:
    ActionSetDoodadCreateParams( int type );

  private:
    void Execute( bool forward );

    int m_typeNext, m_typePrev;
};

// -----------------------------------------------------------------------------
// ! Delete Doodads
// -----------------------------------------------------------------------------
class ActionDeleteDoodads : public Action
{
  public:
    ActionDeleteDoodads( const RCEntityMap &doodads );

  private:
    void Execute( bool forward );

    std::vector< ModDoodadPars > m_deletedDoodads;
};

// -----------------------------------------------------------------------------
// ! Move Doodads
// -----------------------------------------------------------------------------
class ActionMoveDoodads : public Action
{
  public:
    ActionMoveDoodads( const RCEntityMap &doodads, const RowColPair &dir );

  private:
    void Execute( bool forward );

    std::vector< RowColPair > m_doodadPosVec;
    RowColPair m_dir;
};

class ActionCreatePointLight : public Action
{
  public:
    ActionCreatePointLight( const D3DXVECTOR3 &pos, D3DCOLOR color, float atten, float radius );

  private:
    void Execute( bool forward );

    PointLightPars m_light;
};

class ActionDeletePointLights : public Action
{
  public:
    ActionDeletePointLights( const EntityPtrList &lights );

  private:
    void Execute( bool forward );

    std::vector< PointLightPars > m_lights;
};

class ActionMovePointLights : public Action
{
  public:
    ActionMovePointLights( const std::vector< D3DXVECTOR3 > &prev, 
                           const std::vector< D3DXVECTOR3 > &next );

  private:
    void Execute( bool forward );

    std::vector< D3DXVECTOR3 > m_prev;
    std::vector< D3DXVECTOR3 > m_next;
};

// =============================================================================
// ! Action Manager
// =============================================================================
class ActionWrapper
{
  public:
    ActionWrapper( Action *pAction = NULL ) : m_pAction( pAction ) {}
    ~ActionWrapper( void ) { SAFE_DELETE( m_pAction ); }

    Action *GetAction( void ) { return m_pAction; }
    void SoftDestruct( void ) { m_pAction = NULL; }

  private:
    Action *m_pAction;
};

typedef std::list< ActionWrapper >  ActionList;
typedef ActionList::iterator        ActionListIt;
